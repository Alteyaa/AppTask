package com.apptask.activities;

public class Prefs {

}
